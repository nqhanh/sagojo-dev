<?php
    if(isset($_POST['tag']) && $_POST['tag'] != '')
    {
        
        require_once("PHPExcel/IOFactory.php");
        require_once("PHPExcel.php");
        
        $tag=$_POST['tag'];
        $birthday=$_POST['birthday'];
        
        
        
        if($tag == 'excel')
        {
            $excel1 = PHPExcel_IOFactory::createReader('Excel2007');
            $excel1 = $excel1->load('birth102b_opens.xlsx');
            $excel1->setActiveSheetIndex(1);
            $excel1->getActiveSheet()->setCellValue('K2', $birthday);
            
            $response["success"] = 1;
			$response["msg"] = $excel1->getActiveSheet()->getCell('C22')->getFormattedValue();

            echo json_encode($response);
        }
        else
        {
            echo "Invalid Request";
        }
    }
    else
    {
        echo "Access Denide";
    }
?>