<?php
	
	$cal_detail_width_skin = $cal_detail_width;
	
	$content.= "<style>
		#evcal_list li .evcal_desc{width:".$cal_detail_width_skin."px}
	
	</style>";

?>