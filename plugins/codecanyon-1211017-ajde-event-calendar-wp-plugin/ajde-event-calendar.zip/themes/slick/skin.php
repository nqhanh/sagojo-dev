<?php
	
	$cal_detail_width_slick = $cal_detail_width-30;
	
	$content.= "<style>
		#evcal_list li .evcal_desc{width:".$cal_detail_width_slick."px}
	
	</style>";

?>