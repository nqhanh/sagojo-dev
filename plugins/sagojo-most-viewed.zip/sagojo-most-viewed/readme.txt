=== sagojo Most Read & Recent Post plugin ===
For display 2 widget: Most Read Posts by Category and Recent Posts by Category

=== How to use ===
Install plugin.
Add this when the loop starts within single.php: setPostViews(get_the_ID());