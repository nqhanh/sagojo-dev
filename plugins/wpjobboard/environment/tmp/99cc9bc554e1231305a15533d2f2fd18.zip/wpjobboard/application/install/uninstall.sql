SET FOREIGN_KEY_CHECKS =0; --

DROP TABLE `wpjb_additional_field` ; --
DROP TABLE `wpjb_alert` ; --
DROP TABLE `wpjb_application` ; --
DROP TABLE `wpjb_career_builder_log` ; --
DROP TABLE `wpjb_category` ; --
DROP TABLE `wpjb_discount` ; --
DROP TABLE `wpjb_employer` ; --
DROP TABLE `wpjb_field_option`; --
DROP TABLE `wpjb_field_value` ; --
DROP TABLE `wpjb_job` ; --
DROP TABLE `wpjb_job_search` ; --
DROP TABLE `wpjb_listing` ; --
DROP TABLE `wpjb_mail` ; --
DROP TABLE `wpjb_payment` ; --
DROP TABLE `wpjb_resume` ; --
DROP TABLE `wpjb_resumes_access` ; --
DROP TABLE `wpjb_type` ; --
