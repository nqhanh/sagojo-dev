<?php
/**
 * Description of CareerBuilderLog
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_CareerBuilderLog extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_career_builder_log";

    protected function _init()
    {

    }
}

?>