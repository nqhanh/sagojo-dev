<?php
/**
 * Description of Email
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_Email extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_mail";

    protected function _init()
    {
    }
}

?>