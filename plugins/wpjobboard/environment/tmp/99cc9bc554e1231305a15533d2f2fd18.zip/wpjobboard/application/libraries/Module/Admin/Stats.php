<?php
/**
 * Description of Stats
 *
 * @author greg
 * @package 
 */

class Wpjb_Module_Admin_Stats extends Wpjb_Controller_Admin
{
    public function indexAction()
    {
        // ajaxified
    }
}

?>