
    <div id="wpjb-license">&nbsp;</div>
    <br class="clear" />

</div>