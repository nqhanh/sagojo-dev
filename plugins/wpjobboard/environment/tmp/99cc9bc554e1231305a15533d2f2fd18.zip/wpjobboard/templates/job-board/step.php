
<h2 id="wpjb-step">
    <?php wpjb_render_step(1); ?> |
    <?php wpjb_render_step(2); ?> |
    <?php wpjb_render_step(3); ?>
</h2>