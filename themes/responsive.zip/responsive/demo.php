<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sagojo CSV imported</title>
</head>

<body>
<?php
$db = mysql_connect("localhost", "root", "") or die("Could not connect.");

if(!$db) 

	die("no db");

if(!mysql_select_db("sagojo",$db))

 	die("No database selected.");

if(isset($_GET['submit']))

   {

     $filename=$_GET['filename'];
	 
     $handle = fopen("$filename", "r");

     while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
     {
       $import="INSERT into  wpjb_discount(title,code,discount,type,currency,expires_at,is_active,used,max_uses) values('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]')";

       mysql_query($import) or die(mysql_error());
     }

     fclose($handle);

     print "Import done";

   }

   else

   {
      print "<form action='demo.php' method='get'>";

      print "Type file name to import:<br>";

      print "<input type='file' name='filename' size='20' width=40 value='coupon.csv'><br>";

      print "<input type='submit' name='submit' value='submit'></form>";
   }


?>
</body>
</html>
