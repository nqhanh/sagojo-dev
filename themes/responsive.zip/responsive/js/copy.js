$(document).ready(function(){
	$("#copyright").html('Copyright ? 2004 - 2010 MopStudio. All rights resserved.');
});