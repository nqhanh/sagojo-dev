var os = (navigator.appVersion.indexOf ("Win", 0) != -1) ? "win" : "mac";
	document.write ('<link rel="stylesheet" href="css/font_' + os + '.css" type="text/css" />');