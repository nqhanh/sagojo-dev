-------------------------------------------------------
    Thank you for downloading Responsive Theme!
-------------------------------------------------------
This and any other Theme provided by ThemeID should
be free of bugs, however do note that we're only humans
and if you spot a bug do us a favor and report here
http://cyberchimps.com/forum/free/responsive/

If something goes wrong, or you need our assistance with anything
just register and post your question(s).

-------------------------------------------------------
    Responsive Features:
-------------------------------------------------------

- Theme Options
From here you can customize your above the fold
section such as your headline, sub-headline and content.
Also your call to action button text and URL. As well as
an image on the right. Image can be just that or even YouTube
or any other video too.

- Widgets
Well you're in luck my friend, Responsive offers 9 of them.
And yes 3 boxes in your home.php are widgets as well.

- Page Templates
There is plenty of that. 9 Templates are very much self-explanatory
once you're on done with the content on your page, go to Page Attributes
on the right and choose any available Template.

We Have:
Blog (full posts), Blog Summaries, Content/Sidebar, Sidebar/Content,
Content/Sidebar Half, Sidebar/Content Half, Full Width Page, even a 
landing page in case that you don't want anything else but the clean
white design and your logo, perfect for PPC or anything else. There's
also a sitemap Template.

- Menus
Oh boy, we love menus and that's why we decided to give you little bit
more than what you're probably use to. Responsive offers 4 of them
One at very top, second in header, third just after the header, we like
to call that sub-header menu and the fourth one is all the way down in
footer area. 

What's great about this is that the other 3 are kind of on-demand,
activate when needed, if not oh well...

-------------------------------------------------------
    License:
-------------------------------------------------------

Yes I know, but we have to say few words about
that.

The Theme itself is nothing but 100% GPL3. 
See license.txt for further details. There
are however some parts of this Theme which are not
GPL, however they are GPL-Compatible and thats still
good.

See headers of JS files for further details.

-------------------------------------------------------
    Adopting Responsive Theme (Theme Re-Distribution):
-------------------------------------------------------

It's GPL so yes you can base your Themes from Responsive
please note that if you do the GPLv3 License needs to stay
as well as all copyright notices included in all parts of
this Theme as well as third-party add-ons as listed above.

All derivative Themes must be much different from the original
work, which includes the Theme design as well as all the codes
from Responsive Theme.