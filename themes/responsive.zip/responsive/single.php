<?php

// Exit if accessed directly
if ( !defined('ABSPATH')) exit;

/**
 * Single Posts Template
 *
 *
 * @file           single.php
 * @package        Responsive 
 * @author         Emil Uzelac 
 * @copyright      2003 - 2013 ThemeID
 * @license        license.txt
 * @version        Release: 1.0
 * @filesource     wp-content/themes/responsive/single.php
 * @link           http://codex.wordpress.org/Theme_Development#Single_Post_.28single.php.29
 * @since          available since Release 1.0
 */

get_header(); ?>


<div id="content" class="<?php echo implode( ' ', responsive_get_content_classes() ); ?>">
      
	<?php get_template_part( 'loop-header' ); ?>
         
	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>
        
			<?php responsive_entry_before(); ?>
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>   
					<div class="breadcrumbs">
			<span><a href="<?php echo site_url();?>" title="Home">Home</a>
			<?php /*printf( __( '%s', 'max-magazine' ), '<span>' . single_cat_title( '', false ) . '</span>' ); */?>
			<?php the_category(' ','multiple'); ?></span><!--<span><?php the_title(); ?></span>-->
 
		</div>
				<?php responsive_entry_top(); ?>

                <?php get_template_part( 'post-meta' ); ?> <!--chay den trang post-meta.php-->
				
                <div class="post-entry">
						<?php echo "<div class='blog-author-info'>";
						$author_id=$post->post_author;
						$user_info = get_userdata($author_id);
						$category = get_the_category();	
						$user_url = $user_info->user_url;
						if (empty($user_url)) $user_url = "http://www.sagojo.com";
						echo get_avatar( $author_id, 70 );
						echo "<div class='blog-author-info-content'><div class='blog-display_name'>".$user_info->display_name."</div>";
						echo "<div class='blog-text'><div class='blog-cat-date-post'>On ".get_the_date()."</div>";
						echo "<div class='blog-cat-title'>".$user_url."</div></div></div>";
						echo "</div>";
						the_content(__('Read more &#8250;', 'responsive')); ?>
						<?php setPostViews(get_the_ID());?>
                    <?php if ( get_the_author_meta('description') != '' ) : ?>
                    
                    <div id="author-meta">
                    <?php if (function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '80' ); }?>
                        <div class="about-author"><?php _e('About','responsive'); ?> <?php the_author_posts_link(); ?></div>
                        <p><?php the_author_meta('description') ?></p>
                    </div><!-- end of #author-meta -->
                    
                    <?php endif; // no description, no author's meta ?>
                   	<div class="fb-like" style="text-align:center;" data-href="<?php echo get_permalink();?>" data-colorscheme="light" data-layout="button_count" data-action="like" data-show-faces="true" data-send="false"></div>
                    <?php wp_link_pages(array('before' => '<div class="pagination">' . __('Pages:', 'responsive'), 'after' => '</div>')); ?>
                </div><!-- end of .post-entry -->
                
                <!--Phan nay minh se biet duoc noi dung cu cung lien quan nhe.Quan trong-->
                <div class="panavigation">
			        <div class="previous"><?php previous_post_link( '<h2 style="font-size:18px; margin:0;"><span class="meta-nav">%link</h2>' ); ?></div>
                    <div class="next"><?php next_post_link('<h2 style="font-size:18px; margin:0;">%link <span class="meta-nav"></h2>' ); ?></div>
                    <div style="clear: both;"></div>
		        </div><!-- end of .navigation -->
                
                <?php get_template_part( 'post-data' ); ?>
				               
				<?php responsive_entry_bottom(); ?>      
			</div><!-- end of #post-<?php the_ID(); ?> -->       
			<?php //responsive_entry_after(); ?>            
            
			<?php //responsive_comments_before(); ?>
			<?php //comments_template( '', true ); ?>
			<?php //responsive_comments_after(); ?>
            
        <?php 
		endwhile; 

		get_template_part( 'loop-nav' ); 

	else : 

		get_template_part( 'loop-no-posts' ); 

	endif; 
	?>  
      
</div><!-- end of #content -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
