jQuery(document).ready(function(){
	/*
	 * AT_Options_date function
	 * Adds datepicker js
	 */
	jQuery('.athemes-opts-datepicker').datepicker();
});