<div id="instructions">
	<h2>How to use</h2>
	<p>
	Simply navigate to the edit screen for the post or page on which you would like the form to appear and click the Registration button on the TinyMCE (shown at the right). 
	</p>

	<p>For updates please visit: <a href="http://www.mikevanwinkle.com/simplr-registration-form-plus/" title="Simplr Registration Form" target="_blank">http://www.mikevanwinkle.com/simplr-registration-form-plus/</a></p>

	<div id="inst-video">
	<iframe src="http://player.vimeo.com/video/23532472?title=0&amp;byline=0&amp;portrait=0" width="600" height="450" frameborder="0"></iframe>
	</div>

	</div>
